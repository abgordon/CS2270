#include <cstddef>
#include <iostream>
#ifndef BST_H
#define BST_H

template<class Item>
class bstNode
{
	public:
	//constructor
	bstNode(const Item& init_data, bstNode* init_left=NULL, bstNode* init_right= NULL)
		{
			data_field = init_data;
			left_field = init_left;
			right_field = init_right;
		}
	//helper functions if you need them ..
	//I think I haven't used any of them so far	
	//Item& get_data() {return data_field;}
	void set_data(Item& target) {data_field=target;}
	bstNode*& get_left() {return left_field;}
	bstNode*& get_right() {return right_field;}
	
	//FUNCTIONS YOU IMPLEMENT BELOW
	bool find(Item& targetData);
	void insert(Item& targetData);
	void remove(Item& targetData);
	int size();
	void traverse();
	
	//our private variables (we just have 3)
	private:
		Item data_field; //our data
		bstNode* left_field; //pointer to left child
		bstNode* right_field; //pointer to right child
};
//ALL OUR IMPLEMENTATIONS GO IN HERE-- NO .CPP FILE FOR BSTNODE BECUASE IT'S A TEMPLATE CLASS
template<class Item>
bool bstNode<Item>::find(Item& targetData)
{
	//check my self, check my children... if I find targetData I return true, else false
	}

template<class Item>
void bstNode<Item>::insert(Item& targetData)
{
	//go through and find the correct place to insert a new node
	//with this data, remember that you print out the tree in 
	//that specific format after you insert!
}

template<class Item>
void bstNode<Item>::traverse()
{
	//print out the sequence of data using IN ORDER traversal
}

template<class Item>
void bstNode<Item>::remove(Item& targetData)
{
	//go through and remove the item and remake the tree
}

template<class Item>
int bstNode<Item>::size()
{
	//go through and count the number of nodes in this
}
#endif